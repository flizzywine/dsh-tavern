package io.github.flizzywine.dshtavern.bionic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.net.ConnectivityManager;
import android.net.ProxyInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.system.Os;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 前台服务：首次运行把 assets/payload.bin 解到 files/t，用 nativeLibraryDir 里的 libnode.so（Termux 编译的
 * bionic Node）拉起酒馆 DSH。负责启停、意外退出后自动重启、唤醒锁，以及两档更新（源码热更新 / 新版 APK）。
 * 所有操作在一个串行线程里执行；界面通过静态字段读取状态。
 */
public final class TavernService extends Service {
    static final int PORT = 3081;
    static final String ACTION_START = "start", ACTION_STOP = "stop", ACTION_RESTART = "restart", ACTION_EXIT = "exit",
            ACTION_CHECK = "check", ACTION_SOURCE_UPDATE = "source-update",
            ACTION_DOWNLOAD_APK = "download-apk", ACTION_PREFS = "prefs", ACTION_APK_CHECK = "apk-check",
            ACTION_LAN_SYNC = "lan-sync", ACTION_FACTORY_RESET = "factory-reset", ACTION_REPAIR = "repair",
            ACTION_RESCUE_LIST = "rescue-list", ACTION_RESCUE_EXPORT = "rescue-export",
            ACTION_RESCUE_CLEANUP = "rescue-cleanup";
    static final String EXTRA_RESCUE_SELECTION = "rescueSelection",
            EXTRA_RESCUE_INCLUDE_IMAGES = "rescueIncludeImages",
            EXTRA_RESCUE_RAW_ONLY = "rescueRawOnly";
    static final String PREFS = "launcher";
    // 新版安装包的发布信息：先读 GitHub raw（不滞后），失败再读 jsDelivr。与酒馆 Release 解耦，发新酒馆版本不影响它。
    static final String[] APK_FEEDS = {
            "https://raw.githubusercontent.com/flizzywine/dsh-tavern/main/android/native/latest.json",
            "https://cdn.jsdelivr.net/gh/flizzywine/dsh-tavern@main/android/native/latest.json",
            // 1.0.0-beta.1 读的旧地址：新地址还没发布时兜底。
            "https://github.com/flizzywine/dsh-tavern/releases/latest/download/dsh-tavern-native.json"};
    private static final long APK_CHECK_INTERVAL_MS = 6 * 3600_000L;
    private static final String CHANNEL = "tavern";
    // 参数名拆开写：避免被日志脱敏误伤。
    private static final Pattern URL = Pattern.compile("dsh web: (http://127\\.0\\.0\\.1:\\d+/\\?" + "tok" + "en=\\S+)");
    private static final Pattern TOOL_STATUS = Pattern.compile("^DSH_STATUS (.*)$");
    private static final Pattern TOOL_PROGRESS = Pattern.compile("^DSH_PROGRESS (\\d+)$");

    // ---- 给界面看的状态 ----
    static volatile String phase = "idle"; // idle preparing starting running stopping stopped updating failed
    static volatile String status = "准备中";
    static volatile String url;
    static volatile String error;
    static volatile int progress = -1;
    static volatile long runningSince;
    static volatile String lastExit;
    static volatile int autoRestarts;
    static volatile String sourceInfo = "";
    // 局域网访问
    static volatile List<String> lanIps = Collections.emptyList();
    static volatile String lanError;
    // 更新
    static volatile String updateState = "idle"; // idle checking up-to-date source apk needs-apk updating downloading ready installing error
    static volatile String updateMessage = "";
    static volatile JSONObject apkRelease;
    static volatile String apkFile;
    // 启动页自动检查到的新版安装包：需要弹窗提示时非空（已排除用户跳过的版本）。
    static volatile JSONObject apkNotice;
    static volatile boolean apkForced; // 当前版本低于 minVersionCode：不能跳过
    // 修复酒馆：完成后给界面弹窗的结果（repairReportAt 变化时弹一次）
    static volatile String repairReport;
    static volatile long repairReportAt;
    static volatile boolean repairOk;
    // 救援存档：rescueListAt 变化时弹出选区界面；rescueReportAt 变化时弹一次结果；产物路径见 rescueFile / rescueFileName
    static volatile JSONObject rescueCatalog;
    static volatile String rescueListError;
    static volatile long rescueListAt;
    static volatile String rescueReport;
    static volatile long rescueReportAt;
    static volatile boolean rescueOk;
    static volatile String rescueFile;
    static volatile String rescueFileName;
    static volatile boolean rescueIsRaw;
    private static final ArrayDeque<String> tail = new ArrayDeque<>();

    private final ExecutorService ops = Executors.newSingleThreadExecutor();
    private final LanProxy lanProxy = new LanProxy();
    private volatile List<String> trustedLanIps = Collections.emptyList();
    private volatile Process process;
    private volatile boolean wantRunning;
    private volatile boolean stopping;
    private volatile boolean exited;
    private volatile boolean rescueExporting;
    private final java.util.concurrent.atomic.AtomicBoolean apkChecking = new java.util.concurrent.atomic.AtomicBoolean();
    private final java.util.concurrent.atomic.AtomicBoolean rescueListing = new java.util.concurrent.atomic.AtomicBoolean();
    private final ArrayDeque<Long> crashes = new ArrayDeque<>();
    private PowerManager.WakeLock wakeLock;
    private File root;

    static String tail() {
        synchronized (tail) {
            return String.join("\n", tail);
        }
    }

    static List<String> lanUrls() {
        String current = url;
        List<String> ips = lanIps;
        if (current == null || ips.isEmpty()) return Collections.emptyList();
        int q = current.indexOf('?');
        String suffix = q >= 0 ? current.substring(q) : "";
        List<String> out = new ArrayList<>(ips.size());
        for (String ip : ips) out.add("http://" + ip + ":" + PORT + "/" + suffix);
        return out;
    }

    static void log(String line) {
        synchronized (tail) {
            tail.addLast(line);
            while (tail.size() > 80) tail.removeFirst();
        }
    }

    static Intent intent(Context context, String action) {
        return new Intent(context, TavernService.class).setAction(action);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        root = new File(getFilesDir(), "t");
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "酒馆服务", NotificationManager.IMPORTANCE_LOW));
        Notification n = notification("正在准备");
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        PowerManager pm = getSystemService(PowerManager.class);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dshtavern:server");
        wakeLock.setReferenceCounted(false);
    }

    private int statIcon() {
        int id = getResources().getIdentifier("ic_stat_tavern", "drawable", getPackageName());
        return id != 0 ? id : android.R.drawable.ic_dialog_info;
    }

    private Notification notification(String text) {
        JSONObject notice = apkNotice;
        Intent openIntent = new Intent(this, MainActivity.class);
        // 有新版安装包时，点通知回到启动页并弹出提示（默认会直接进酒馆，启动页上的提示看不到）。
        if (notice != null) openIntent.putExtra(MainActivity.EXTRA_SHOW_UPDATE, true);
        PendingIntent open = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent exit = PendingIntent.getService(this, 1, intent(this, ACTION_EXIT), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setContentTitle("DSH Tavern Beta")
                .setContentText(text)
                .setSmallIcon(statIcon())
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "退出", exit).build())
                .setOngoing(true);
        if (notice != null) b.setSubText("有新版安装包 " + notice.optString("versionName"));
        else if (!lanIps.isEmpty()) b.setSubText("局域网：" + lanIps.get(0) + ":" + PORT);
        return b.build();
    }

    private void notify(String text) {
        if (exited) return; // 已退出：检查线程晚到的刷新不能把通知再挂回去
        getSystemService(NotificationManager.class).notify(1, notification(text));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null || intent.getAction() == null ? ACTION_START : intent.getAction();
        // 安装包检查、救援只读扫描与缓存清理不排进串行线程，不打断运行中的酒馆服务。
        if (ACTION_APK_CHECK.equals(action)) {
            new Thread(this::apkCheck, "apk-check").start();
            return START_STICKY;
        }
        if (ACTION_RESCUE_LIST.equals(action)) {
            new Thread(this::rescueList, "rescue-list").start();
            return START_STICKY;
        }
        if (ACTION_RESCUE_CLEANUP.equals(action)) {
            new Thread(this::cleanupRescueCache, "rescue-cleanup").start();
            return START_STICKY;
        }
        final String rescueSelection = intent != null ? intent.getStringExtra(EXTRA_RESCUE_SELECTION) : null;
        final boolean rescueIncludeImages = intent != null && intent.getBooleanExtra(EXTRA_RESCUE_INCLUDE_IMAGES, false);
        final boolean rescueRawOnly = intent != null && intent.getBooleanExtra(EXTRA_RESCUE_RAW_ONLY, false);
        // 被系统杀掉后重建（START_STICKY 送来 null intent）：用户之前想让它运行，就接着运行。
        ops.execute(() -> handle(action, rescueSelection, rescueIncludeImages, rescueRawOnly));
        return START_STICKY;
    }

    private void handle(String action, String rescueSelection, boolean rescueIncludeImages, boolean rescueRawOnly) {
        try {
            switch (action) {
                case ACTION_START:
                    wantRunning = true;
                    if (process == null) startServer();
                    break;
                case ACTION_STOP:
                    wantRunning = false;
                    stopServer();
                    setPhase("stopped", "已停止");
                    break;
                case ACTION_RESTART:
                    wantRunning = true;
                    stopServer();
                    startServer();
                    break;
                case ACTION_EXIT:
                    wantRunning = false;
                    stopServer();
                    setPhase("stopped", "已退出");
                    exited = true;
                    stopForeground(STOP_FOREGROUND_REMOVE);
                    stopSelf();
                    break;
                case ACTION_REPAIR:
                    wantRunning = true;
                    stopServer();
                    repair();
                    break;
                case ACTION_FACTORY_RESET:
                    wantRunning = true;
                    stopServer();
                    factoryReset();
                    startServer();
                    break;
                case ACTION_RESCUE_EXPORT: {
                    // 导出时不能有人在写存档：先停掉酒馆，导完恢复原来的状态（在运行就重新启动）。
                    boolean resume = process != null;
                    String prevPhase = phase, prevStatus = status, prevError = error;
                    stopServer();
                    error = null;
                    rescueExport(rescueSelection, rescueIncludeImages, rescueRawOnly);
                    if (resume) {
                        wantRunning = true;
                        startServer();
                    } else {
                        wantRunning = false;
                        error = prevError;
                        if ("failed".equals(prevPhase)) setPhase("failed", prevStatus);
                        else setPhase("stopped", "已停止");
                    }
                    break;
                }
                case ACTION_CHECK:
                    checkUpdates();
                    break;
                case ACTION_SOURCE_UPDATE:
                case ACTION_DOWNLOAD_APK:
                    try {
                        if (ACTION_SOURCE_UPDATE.equals(action)) sourceUpdate();
                        else downloadApk();
                    } catch (Throwable t) {
                        // 更新失败不等于服务失败：服务照常运行（sourceUpdate 自己负责回退）。
                        progress = -1;
                        updateState = "error";
                        updateMessage = "更新失败：" + (t.getMessage() != null ? t.getMessage() : t);
                        log(android.util.Log.getStackTraceString(t));
                        if (wantRunning && process == null) startServer();
                    }
                    break;
                case ACTION_PREFS:
                    applyWakeLock();
                    // 跳过某个安装包版本后，按上次读到的发布信息重算提示，通知栏的「有新版」随之去掉。
                    String cached = prefs().getString("apkLatest", null);
                    if (cached != null) updateNotice(new JSONObject(cached));
                    else notify(status);
                    break;
                case ACTION_LAN_SYNC:
                    syncLan();
                    break;
                default:
                    break;
            }
        } catch (Throwable t) {
            error = String.valueOf(t.getMessage() != null ? t.getMessage() : t);
            setPhase("failed", "失败");
            log(android.util.Log.getStackTraceString(t));
        }
    }

    @Override
    public void onDestroy() {
        wantRunning = false;
        exited = true;
        stopLanProxy();
        Process p = process;
        if (p != null) p.destroy();
        if (wakeLock.isHeld()) wakeLock.release();
        ops.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void setPhase(String newPhase, String text) {
        phase = newPhase;
        status = text;
        notify(text);
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void applyWakeLock() {
        // 熄屏后 CPU 休眠会让 Node 的事件循环停住：生成到一半的回复、后台结算都会卡住。
        boolean want = prefs().getBoolean("wakelock", true) && process != null;
        if (want && !wakeLock.isHeld()) wakeLock.acquire();
        if (!want && wakeLock.isHeld()) wakeLock.release();
    }

    // ---------------------------------------------------------------- 载荷

    private long versionCode() throws Exception {
        return getPackageManager().getPackageInfo(getPackageName(), 0).getLongVersionCode();
    }

    private long installStamp() throws Exception {
        PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
        return info.getLongVersionCode() * 1000003L + info.lastUpdateTime % 1000003L;
    }

    /** 程序文件：每次换 APK 整体替换。其余（存档、凭据、模型设置 cordis.patch.yml 等）只在缺失时播种。 */
    static final String PROFILE = "home/.dsh-tavern/profiles/tavern/";
    static final String USER_CONFIG = PROFILE + "cordis.patch.yml";
    static final String[] PROGRAM_DIRS = {"src/", "usr/", "home/.dsh-tavern/runtime/", "pnpm-cache/"};

    static boolean isProgram(String path) {
        if (path.startsWith(".payload-")) return true;
        for (String dir : PROGRAM_DIRS) if (path.startsWith(dir)) return true;
        return path.startsWith(PROFILE) && !path.equals(USER_CONFIG);
    }

    private JSONObject readJson(File file) {
        try {
            return new JSONObject(new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    private JSONObject payloadSource() {
        try (InputStream in = getAssets().open("payload-source.json")) {
            return new JSONObject(new String(readAll(in), StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    /** 热更新过、比 APK 自带的新、且依赖相同的源码：覆盖安装 APK 时保留。 */
    private boolean keepHotUpdatedSource() {
        JSONObject installed = readJson(new File(root, "src/.native-source.json"));
        JSONObject bundled = payloadSource();
        if (installed == null || bundled == null) return false;
        return "hot-update".equals(installed.optString("from"))
                && installed.optLong("sequence") > bundled.optLong("sequence")
                && installed.optString("fingerprint").equals(bundled.optString("fingerprint"));
    }

    private void ensurePayload(boolean force) throws Exception {
        File marker = new File(getFilesDir(), "payload-" + installStamp() + ".done");
        if (marker.exists() && !force) return;
        setPhase("preparing", "正在准备程序文件");
        boolean upgrade = new File(root, "home").isDirectory();
        boolean keepSource = upgrade && !force && keepHotUpdatedSource();
        long started = System.currentTimeMillis();
        root.mkdirs();
        if (upgrade) {
            status = force ? "正在重置程序文件（存档和设置保留）" : "正在替换程序文件（存档和设置保留）";
            for (String dir : PROGRAM_DIRS) {
                if (keepSource && dir.equals("src/")) continue;
                deleteTree(new File(root, dir));
            }
            deleteTree(new File(root, "src.next"));
            deleteTree(new File(root, "pnpm-store"));
            deleteTree(new File(root, "update-backup"));
            if (!keepSource) deleteTree(new File(root, "src.prev"));
            File profile = new File(root, PROFILE);
            File[] children = profile.listFiles();
            if (children != null) for (File child : children) if (!child.getName().equals("cordis.patch.yml")) deleteTree(child);
        }
        status = upgrade ? status : "首次启动，正在解压（约 1.3 GB，通常二三十秒）";
        progress = 0;
        TarExtractor extractor = new TarExtractor(root, path -> !isProgram(path), path -> keepSource && path.startsWith("src/"));
        try (AssetFileDescriptor fd = getAssets().openFd("payload.bin")) {
            final long total = fd.getLength();
            InputStream raw = new FilterInputStream(fd.createInputStream()) {
                long done;

                @Override
                public int read(byte[] b, int off, int len) throws IOException {
                    int n = super.read(b, off, len);
                    if (n > 0) {
                        done += n;
                        progress = (int) (done * 100 / total);
                    }
                    return n;
                }
            };
            try (InputStream in = new GZIPInputStream(new BufferedInputStream(raw, 1 << 20), 1 << 16)) {
                extractor.extract(in);
            }
        }
        rewriteRoot(root);
        File[] old = getFilesDir().listFiles((dir, name) -> name.startsWith("payload-") && name.endsWith(".done"));
        if (old != null) for (File f : old) f.delete();
        marker.createNewFile();
        log((upgrade ? "程序文件已更新" : "解压完成") + "：写入 " + extractor.written + " 个，保留已有文件 " + extractor.kept
                + " 个" + (keepSource ? "（保留热更新过的源码）" : "") + "，用时 " + (System.currentTimeMillis() - started) / 1000 + " 秒");
        progress = -1;
    }

    /**
     * 修复酒馆：从轻到重，只移动不删除用户文件。
     * 1. 清掉更新中途留下的中间产物；2. 数据体检（{@link DataRepair}），坏文件进 files/t/quarantine/&lt;时间&gt;；
     * 3. 重新解出程序文件（撤销应用内更新），顺带补回缺失的自带文件；4. 启动并等服务就绪。
     * 结果写进 repairReport 给界面弹窗，完整报告在 files/logs/repair.log。
     */
    private void repair() throws Exception {
        long started = System.currentTimeMillis();
        List<String> report = new ArrayList<>();
        setPhase("preparing", "正在修复：清理更新留下的中间产物");
        progress = -1;
        for (String leftover : new String[]{"src.next", "update-backup", "pnpm-store"}) {
            File f = new File(root, leftover);
            if (f.exists()) {
                deleteTree(f);
                report.add("清掉中间产物 " + leftover);
            }
        }
        DataRepair data = null;
        if (new File(root, "home").isDirectory()) {
            setPhase("preparing", "正在修复：检查存档和设置文件");
            String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new java.util.Date());
            data = new DataRepair(root, new File(root, "quarantine/" + stamp));
            data.run();
            report.addAll(data.notes);
        }
        status = "正在修复：重新解出程序文件";
        ensurePayload(true);
        report.add("已重新解出程序文件（应用内更新已撤销，可再检查更新）");
        autoRestarts = 0;
        synchronized (crashes) {
            crashes.clear();
        }
        startServer();
        boolean ok = waitRunning(180_000);

        StringBuilder summary = new StringBuilder();
        if (data != null) {
            summary.append("检查了 ").append(data.checked).append(" 个数据文件");
            if (data.restored + data.quarantined + data.trimmed + data.leftovers == 0) summary.append("，没有发现损坏。");
            else {
                summary.append("：");
                List<String> parts = new ArrayList<>();
                if (data.restored > 0) parts.add("用备份恢复 " + data.restored + " 个");
                if (data.trimmed > 0) parts.add("修好 " + data.trimmed + " 个写到一半的记录");
                if (data.quarantined > 0) parts.add("移走 " + data.quarantined + " 个损坏文件");
                if (data.leftovers > 0) parts.add("清掉 " + data.leftovers + " 个临时文件");
                summary.append(String.join("，", parts)).append("。");
            }
            if (data.unresolved > 0) summary.append("\n有 ").append(data.unresolved).append(" 处没能自动处理，详见日志。");
            if (data.changed()) summary.append("\n移走的原文件保存在 ").append(data.quarantineRelative()).append("。");
            if (data.credentialsReset) summary.append("\n模型与 API key 设置文件已损坏并重置，请重新填写。");
        }
        summary.append(summary.length() > 0 ? "\n" : "").append("程序文件已重新解出。");
        summary.append(ok ? "\n\n酒馆已正常启动。" : "\n\n酒馆仍然无法启动。可以先「救援存档」把存档导出来，再「分享日志」反馈问题；确认无法挽救时再用「完全重置」。");
        repairOk = ok;
        repairReport = summary.toString();
        repairReportAt = System.currentTimeMillis();

        File logs = new File(getFilesDir(), "logs");
        logs.mkdirs();
        StringBuilder full = new StringBuilder("修复于 ")
                .append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new java.util.Date(started)))
                .append("，用时 ").append((System.currentTimeMillis() - started) / 1000).append(" 秒，")
                .append(ok ? "服务已就绪" : "服务未能启动").append('\n');
        for (String line : report) full.append("- ").append(line).append('\n');
        Files.write(new File(logs, "repair.log").toPath(), full.toString().getBytes(StandardCharsets.UTF_8));
        for (String line : report) log("修复：" + line);
        log("修复完成：" + (ok ? "服务已就绪" : "服务未能启动") + "，报告在 logs/repair.log");
        if (!ok && process == null && error == null) {
            error = "修复后酒馆仍无法启动";
            setPhase("failed", "修复后仍无法启动");
        }
    }

    /**
     * 完全重置：删掉整个数据目录（程序文件和全部用户数据），之后按首次启动重新解压。
     * 保留 files/logs（排查用）和启动页设置；WebView 里的数据由界面清掉。
     */
    private void factoryReset() throws Exception {
        setPhase("preparing", "正在完全重置（清除全部数据）");
        progress = -1;
        long started = System.currentTimeMillis();
        deleteTree(root);
        File[] markers = getFilesDir().listFiles((dir, name) -> name.startsWith("payload-") && name.endsWith(".done"));
        if (markers != null) for (File f : markers) f.delete();
        autoRestarts = 0;
        crashes.clear();
        lastExit = null;
        error = null;
        log("已完全重置：清除数据目录，用时 " + (System.currentTimeMillis() - started) / 1000 + " 秒，接着重新解压");
    }

    /** 只读扫描可救援导出的板块与条目，不停服、不改主界面状态；结果供启动页弹出勾选界面。 */
    private void rescueList() {
        if (!rescueListing.compareAndSet(false, true)) return;
        try {
            File dshHome = new File(root, "home/.dsh-tavern");
            if (!dshHome.isDirectory()) {
                rescueCatalog = null;
                rescueListError = "没有找到酒馆数据目录，可能尚未初始化或已被清空";
                rescueListAt = System.currentTimeMillis();
                return;
            }
            File script = new File(root, "src/tavern-plugin/lib/rescue-export.mjs");
            if (!node().canExecute()) {
                rescueCatalog = null;
                rescueListError = "找不到可执行的 libnode.so";
                rescueListAt = System.currentTimeMillis();
                return;
            }
            if (!script.isFile()) {
                rescueCatalog = null;
                rescueListError = "找不到救援导出脚本（程序文件可能已损坏）";
                rescueListAt = System.currentTimeMillis();
                return;
            }
            JSONObject res = runRescueScript(script, Collections.singletonList("--list"), false);
            rescueCatalog = res;
            rescueListError = null;
            rescueListAt = System.currentTimeMillis();
        } catch (Throwable t) {
            rescueCatalog = null;
            rescueListError = t.getMessage() != null ? t.getMessage() : String.valueOf(t);
            rescueListAt = System.currentTimeMillis();
            log("救援扫描失败：" + rescueListError);
        } finally {
            rescueListing.set(false);
        }
    }

    /** 释放 cache/rescue/ 临时包（用户保存完成、关闭弹窗或取消保存后调用，避免占手机空间）。 */
    private void cleanupRescueCache() {
        if (rescueExporting) return;
        rescueFile = null;
        rescueFileName = null;
        try {
            deleteTree(new File(getCacheDir(), "rescue"));
        } catch (IOException ignored) {
        }
    }

    private static boolean isRescueLimitError(String message) {
        if (message == null) return false;
        return message.contains("请取消一部分板块后分两次导出")
                || message.contains("文件数量过多")
                || message.contains("压缩包超过 4 GB")
                || message.contains("请至少选择")
                || message.contains("所选板块或条目没有可导出的内容");
    }

    /**
     * 救援存档：不启动酒馆，直接调用 tavern-plugin/lib/rescue-export.mjs 流式导出标准 .dshtransfer 包。
     * 支持按用户勾选的 selectionJson 与 includeImages 局部导出；Node 或源码损坏时自动兜底用 Java 打成原始数据 zip。
     * 产物写入 cache/rescue/，随后由界面用 ACTION_CREATE_DOCUMENT 让用户选位置保存，保存或关闭后自动清理缓存。
     */
    private void rescueExport(String selectionJson, boolean includeImages, boolean rawOnly) {
        long started = System.currentTimeMillis();
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new java.util.Date(started));
        List<String> notes = new ArrayList<>();
        rescueExporting = true;
        rescueFile = null;
        rescueFileName = null;
        rescueIsRaw = false;
        setPhase("preparing", rawOnly ? "正在打包原始数据包（兜底）" : "正在救援存档：准备导出环境");
        progress = -1;
        try {
            File dshHome = new File(root, "home/.dsh-tavern");
            if (!dshHome.isDirectory()) {
                finishRescue(false, false, null, null, "没有找到酒馆数据目录，可能尚未初始化或已被清空。", notes, started);
                return;
            }
            File dir = new File(getCacheDir(), "rescue");
            deleteTree(dir);
            dir.mkdirs();

            String primaryError = null;
            if (!rawOnly) {
                File out = new File(dir, "DSH酒馆救援备份-" + stamp + ".dshtransfer");
                File script = new File(root, "src/tavern-plugin/lib/rescue-export.mjs");
                if (!node().canExecute()) {
                    primaryError = "找不到可执行的 libnode.so";
                } else if (!script.isFile()) {
                    primaryError = "找不到救援导出脚本（程序文件可能已损坏）";
                } else {
                    File selFile = null;
                    try {
                        List<String> extraArgs = new ArrayList<>();
                        extraArgs.add("--out");
                        extraArgs.add(out.getPath());
                        extraArgs.add(includeImages ? "--images" : "--no-images");
                        if (selectionJson != null && !selectionJson.isEmpty()) {
                            selFile = new File(dir, "selection.json");
                            Files.write(selFile.toPath(), selectionJson.getBytes(StandardCharsets.UTF_8));
                            extraArgs.add("--selection-file");
                            extraArgs.add(selFile.getPath());
                        }
                        JSONObject res = runRescueScript(script, extraArgs, true);
                        if (out.isFile() && out.length() > 0) {
                            String filename = res.optString("filename", out.getName());
                            if (filename.isEmpty()) filename = out.getName();
                            StringBuilder summary = new StringBuilder();
                            JSONObject totals = res.optJSONObject("totals");
                            int items = totals != null ? totals.optInt("items", 0) : 0;
                            summary.append("已导出标准酒馆备份包（.dshtransfer，共 ").append(items).append(" 项，")
                                    .append(formatBytes(out.length())).append("）。");
                            JSONArray parts = res.optJSONArray("parts");
                            if (parts != null && parts.length() > 0) {
                                List<String> partTexts = new ArrayList<>();
                                for (int i = 0; i < parts.length(); i++) {
                                    JSONObject p = parts.optJSONObject(i);
                                    if (p != null) partTexts.add(p.optString("label") + " " + p.optInt("items"));
                                }
                                if (!partTexts.isEmpty()) summary.append("\n包含：").append(String.join("、", partTexts)).append("。");
                            }
                            summary.append("\n不含 API key 与账号；可直接用酒馆里的「导入」恢复。");
                            JSONArray warnings = res.optJSONArray("warnings");
                            if (warnings != null && warnings.length() > 0) {
                                summary.append("\n\n有 ").append(warnings.length()).append(" 项未能导出（已跳过，详见日志 rescue.log）。");
                                for (int i = 0; i < warnings.length(); i++) notes.add("跳过：" + warnings.optString(i));
                            }
                            notes.add("标准导出成功：" + filename + "（" + formatBytes(out.length()) + "）");
                            finishRescue(true, false, out, filename, summary.toString(), notes, started);
                            return;
                        }
                        primaryError = "导出脚本未生成备份文件";
                    } catch (Throwable t) {
                        primaryError = t.getMessage() != null ? t.getMessage() : String.valueOf(t);
                        notes.add("标准导出失败：" + primaryError);
                        if (isRescueLimitError(primaryError)) {
                            deleteTree(dir);
                            finishRescue(false, false, null, null,
                                    "标准导出未完成：" + primaryError + "\n\n请重新点「救援存档」，减少勾选的板块或条目、分批导出，或取消勾选「含对话配图」。",
                                    notes, started);
                            return;
                        }
                        log("救援存档标准导出失败，将尝试原始数据包兜底：" + primaryError);
                    } finally {
                        if (selFile != null) selFile.delete();
                    }
                }
            } else {
                primaryError = "用户直接选择了兜底原始打包";
            }

            // 兜底：脚本跑不起来时，Java 直接把所有非程序用户文件打成原始 zip，确保数据能带走。
            setPhase("preparing", rawOnly ? "正在打包原始数据包（兜底）" : "标准导出不可用，正在打包原始数据包（兜底）");
            progress = 0;
            File rawZip = new File(dir, "DSH酒馆原始数据包-" + stamp + ".zip");
            int packed = packRawUserDataZip(rawZip);
            progress = -1;
            if (packed == 0 || !rawZip.isFile() || rawZip.length() == 0) {
                deleteTree(dir);
                finishRescue(false, false, null, null,
                        "救援存档失败。\n标准导出失败：" + primaryError + "\n兜底打包也未找到可保存的用户文件。", notes, started);
                return;
            }
            notes.add("兜底原始打包成功：" + rawZip.getName() + "（" + packed + " 个文件，" + formatBytes(rawZip.length()) + "）");
            String summary = (rawOnly
                    ? "已用兜底模式把 "
                    : "酒馆程序或数据损坏导致标准导出失败（" + primaryError + "），已自动改用兜底模式把 ")
                    + packed + " 个用户原始文件打成 ZIP（" + formatBytes(rawZip.length()) + "）。\n\n"
                    + "· 该文件不能直接从酒馆「导入」页导入，可用于手动恢复或排查。\n"
                    + "· 包含本机配置（含 cordis.patch.yml 等），可能含 API key，请妥善保管，不要发给他人。";
            finishRescue(true, true, rawZip, rawZip.getName(), summary, notes, started);
        } catch (Throwable t) {
            progress = -1;
            String msg = t.getMessage() != null ? t.getMessage() : String.valueOf(t);
            notes.add("异常：" + msg);
            log(android.util.Log.getStackTraceString(t));
            finishRescue(false, false, null, null, "救援存档失败：" + msg, notes, started);
        } finally {
            rescueExporting = false;
            progress = -1;
        }
    }

    private JSONObject runRescueScript(File script, List<String> extraArgs, boolean reportStatus) throws Exception {
        List<String> command = new ArrayList<>();
        command.add(node().getPath());
        command.add("--max-old-space-size=1024");
        command.add("--use-bundled-ca");
        File preload = new File(root, "usr/lib/dsh-android/preload.cjs");
        if (preload.isFile()) {
            command.add("--require");
            command.add(preload.getPath());
        }
        command.add(script.getPath());
        command.addAll(extraArgs);
        command.add("--dsh-home");
        command.add(new File(root, "home/.dsh-tavern").getPath());
        command.add("--source-root");
        command.add(new File(root, "src").getPath());

        ProcessBuilder pb = new ProcessBuilder(command);
        baseEnvironment(pb.environment());
        File srcDir = new File(root, "src");
        pb.directory(srcDir.isDirectory() ? srcDir : root);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        JSONObject result = null;
        StringBuilder other = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Matcher sm = TOOL_STATUS.matcher(line);
                if (sm.find()) {
                    if (reportStatus) setPhase("preparing", sm.group(1));
                    continue;
                }
                Matcher pm = TOOL_PROGRESS.matcher(line);
                if (pm.find()) {
                    if (reportStatus) progress = Math.max(0, Math.min(100, Integer.parseInt(pm.group(1))));
                    continue;
                }
                if (line.startsWith("RESULT ")) {
                    result = new JSONObject(line.substring(7));
                } else if (other.length() < 4000) {
                    other.append(line).append('\n');
                }
            }
        }
        p.waitFor();
        if (result == null) throw new IOException("救援脚本没有返回结果：" + other.toString().trim());
        if ("error".equals(result.optString("kind"))) throw new IOException(result.optString("error", "未知错误"));
        return result;
    }

    /** 兜底打包：把 files/t 下所有非程序常规文件（跳过 quarantine、tmp、静态资源缓存与软链接）流式写进 zip。 */
    private int packRawUserDataZip(File zipFile) throws IOException {
        Path base = root.toPath();
        List<Path> files = new ArrayList<>();
        Files.walkFileTree(base, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (dir.equals(base)) return FileVisitResult.CONTINUE;
                String rel = base.relativize(dir).toString().replace(File.separatorChar, '/') + "/";
                if (isProgram(rel) || rel.startsWith("quarantine/") || rel.startsWith("tmp/")
                        || rel.startsWith("src.next/") || rel.startsWith("src.prev/")
                        || rel.startsWith("update-backup/") || rel.startsWith("pnpm-store/")
                        || rel.endsWith("/cache/static-assets/") || rel.endsWith("/tmp-exports/")) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (!attrs.isRegularFile() || attrs.isSymbolicLink()) return FileVisitResult.CONTINUE;
                String rel = base.relativize(file).toString().replace(File.separatorChar, '/');
                if (!isProgram(rel)) files.add(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) {
                return FileVisitResult.CONTINUE;
            }
        });
        int total = files.size();
        if (total == 0) return 0;
        byte[] buf = new byte[1 << 16];
        int written = 0;
        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile), 1 << 16))) {
            for (int i = 0; i < total; i++) {
                Path file = files.get(i);
                String rel = base.relativize(file).toString().replace(File.separatorChar, '/');
                try (InputStream in = new FileInputStream(file.toFile())) {
                    zos.putNextEntry(new ZipEntry(rel));
                    int n;
                    while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                    zos.closeEntry();
                    written++;
                } catch (IOException ignored) {
                }
                progress = Math.min(99, (i + 1) * 100 / total);
            }
        }
        return written;
    }

    private void finishRescue(boolean ok, boolean raw, File file, String filename, String summary, List<String> notes, long started) {
        rescueOk = ok;
        rescueIsRaw = raw;
        rescueFile = ok && file != null ? file.getPath() : null;
        rescueFileName = ok ? filename : null;
        rescueReport = summary;
        rescueReportAt = System.currentTimeMillis();
        try {
            File logs = new File(getFilesDir(), "logs");
            logs.mkdirs();
            StringBuilder full = new StringBuilder("救援导出于 ")
                    .append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new java.util.Date(started)))
                    .append("，用时 ").append((System.currentTimeMillis() - started) / 1000).append(" 秒，")
                    .append(ok ? (raw ? "兜底打包成功" : "标准导出成功") : "失败").append('\n');
            for (String line : notes) full.append("- ").append(line).append('\n');
            Files.write(new File(logs, "rescue.log").toPath(), full.toString().getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignored) {
        }
        log("救援存档：" + (ok ? (raw ? "已打包原始数据 " : "已导出 ") + filename : "失败"));
    }

    static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(Locale.ROOT, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    /** 载荷按打包时的设备路径生成；实际数据目录不同（多用户、工作资料）时改写记录在案的文件。 */
    private void rewriteRoot(File root) throws IOException {
        File built = new File(root, ".payload-root");
        File list = new File(root, ".payload-root-files");
        if (!built.exists() || !list.exists()) return;
        String from = new String(Files.readAllBytes(built.toPath()), StandardCharsets.UTF_8).trim();
        String to = root.getAbsolutePath();
        if (from.equals(to)) return;
        int changed = 0;
        for (String line : Files.readAllLines(list.toPath(), StandardCharsets.UTF_8)) {
            if (line.isEmpty()) continue;
            Path file = new File(root, line).toPath();
            if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) continue;
            String text = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            if (!text.contains(from)) continue;
            Files.write(file, text.replace(from, to).getBytes(StandardCharsets.UTF_8));
            changed++;
        }
        log("数据目录为 " + to + "，已改写 " + changed + " 个文件中的路径");
    }

    /** 递归删除，不跟随软链接（node_modules 里的链接指向 src）。 */
    static void deleteTree(File file) throws IOException {
        Path path = file.toPath();
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return;
        Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path p, BasicFileAttributes attrs) throws IOException {
                Files.delete(p);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path p, IOException e) throws IOException {
                if (e != null) throw e;
                Files.delete(p);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    // ---------------------------------------------------------------- 进程

    private File node() {
        return new File(getApplicationInfo().nativeLibraryDir, "libnode.so");
    }

    private String systemProxy() {
        try {
            ProxyInfo info = getSystemService(ConnectivityManager.class).getDefaultProxy();
            if (info == null || info.getHost() == null || info.getHost().isEmpty() || info.getPort() <= 0) return null;
            return "http://" + info.getHost() + ":" + info.getPort();
        } catch (Exception e) {
            return null;
        }
    }

    private void baseEnvironment(Map<String, String> env) throws IOException {
        File home = new File(root, "home");
        File dsh = new File(home, ".dsh-tavern");
        File tmp = new File(root, "tmp");
        tmp.mkdirs();
        env.clear();
        env.put("HOME", home.getPath());
        env.put("TMPDIR", tmp.getPath());
        env.put("PATH", "/system/bin:/system/xbin");
        env.put("ANDROID_ROOT", "/system");
        env.put("ANDROID_DATA", "/data");
        env.put("LANG", "zh_CN.UTF-8");
        env.put("DSH_HOME", dsh.getPath());
        env.put("DSH_TAVERN_CLI_HOME", dsh.getPath());
        env.put("DSH_TAVERN_RUNTIME_HOST", "cli");
        // 继承环境的子进程（如模板 worker 以外的 node 子进程）同样用自带证书库：Termux 的 CA 路径在 APK 里不存在。
        env.put("NODE_OPTIONS", "--use-bundled-ca");
        // 整体分发：更新由启动页负责，酒馆里的更新器只做检查。
        env.put("DSH_TAVERN_UPDATE_CHANNEL", "apk");
        String proxy = systemProxy();
        if (proxy != null) {
            env.put("HTTP_PROXY", proxy);
            env.put("HTTPS_PROXY", proxy);
            env.put("NO_PROXY", "127.0.0.1,localhost,::1");
            env.put("NODE_USE_ENV_PROXY", "1");
        }
        // 调试钩子：files/t/extra-env 里的 KEY=VALUE 追加进环境（验收用的固定输出模型、测试用的更新源）。
        env.putAll(extraEnv());
    }

    private Map<String, String> extraEnv() {
        Map<String, String> out = new java.util.HashMap<>();
        File extra = new File(root, "extra-env");
        if (!extra.exists()) return out;
        try {
            for (String line : Files.readAllLines(extra.toPath(), StandardCharsets.UTF_8)) {
                int eq = line.indexOf('=');
                if (eq > 0 && !line.startsWith("#")) out.put(line.substring(0, eq).trim(), line.substring(eq + 1).trim());
            }
        } catch (IOException e) {
            log("读取 extra-env 失败：" + e.getMessage());
        }
        return out;
    }

    private void startServer() throws Exception {
        ensurePayload(false);
        File dsh = new File(root, "home/.dsh-tavern");
        File credentials = new File(dsh, ".credentials.yaml");
        if (credentials.exists()) Os.chmod(credentials.getPath(), 0600);
        sourceInfo = describeSource();
        stopLanProxy();
        trustedLanIps = Collections.emptyList();

        List<String> command = new ArrayList<>();
        command.add(node().getPath());
        command.add("--max-old-space-size=1024");
        command.add("--use-bundled-ca");
        command.add("--expose-internals");
        command.add("--require");
        command.add(root + "/usr/lib/dsh-android/preload.cjs");
        command.add(dsh + "/runtime/lib/node_modules/@deepseek-ai/dsh/lib/bin.js");
        command.add("--profile");
        command.add("tavern");
        command.add("--host");
        command.add("127.0.0.1");
        command.add("--port");
        command.add(String.valueOf(PORT));
        command.add("--no-open");
        if (prefs().getBoolean("lanAccess", false)) {
            List<String> candidates = LanProxy.discoverLanAddresses(this);
            if (!candidates.isEmpty()) {
                for (String ip : candidates) {
                    command.add("--trusted-host");
                    command.add(ip + ":" + PORT);
                }
                trustedLanIps = candidates;
            } else {
                lanError = "未检测到 Wi-Fi 或局域网地址（请连接 Wi-Fi 或开启热点后点「刷新地址」）";
            }
        }

        ProcessBuilder pb = new ProcessBuilder(command);
        baseEnvironment(pb.environment());
        if (systemProxy() != null) log("使用系统代理 " + systemProxy());
        pb.directory(new File(root, "src"));
        pb.redirectErrorStream(true);

        File logs = new File(getFilesDir(), "logs");
        logs.mkdirs();
        rotate(new File(logs, "node.log"));
        error = null;
        url = null;
        setPhase("starting", "正在启动酒馆");
        long started = System.currentTimeMillis();
        stopping = false;
        Process p = pb.start();
        process = p;
        applyWakeLock();
        Thread reader = new Thread(() -> pump(p, new File(logs, "node.log"), started), "tavern-log");
        reader.start();
    }

    private static void rotate(File log) {
        if (log.exists() && log.length() > 0) log.renameTo(new File(log.getParentFile(), "node.prev.log"));
    }

    private void pump(Process p, File logFile, long started) {
        try (OutputStream file = new FileOutputStream(logFile);
             BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                file.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                file.flush();
                log(line);
                if (url == null && process == p) {
                    Matcher m = URL.matcher(line);
                    if (m.find()) {
                        url = m.group(1);
                        runningSince = System.currentTimeMillis();
                        setPhase("running", "运行中（启动用时 " + (System.currentTimeMillis() - started) + " ms）");
                        ops.execute(() -> activateLanForProcess(p));
                    }
                }
            }
        } catch (IOException ignored) {
        }
        int code;
        try {
            code = p.waitFor();
        } catch (InterruptedException e) {
            return;
        }
        if (process != p) return;
        process = null;
        url = null;
        stopLanProxy();
        trustedLanIps = Collections.emptyList();
        applyWakeLock();
        lastExit = "退出码 " + code + (code > 128 ? "（信号 " + (code - 128) + "）" : "") + "，"
                + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT).format(new java.util.Date());
        if (stopping || !wantRunning) return;
        // 意外退出：系统杀后台子进程（Android 12+ phantom process）、内存不足或程序崩溃。5 分钟内最多自动重启 3 次。
        long now = System.currentTimeMillis();
        synchronized (crashes) {
            crashes.addLast(now);
            while (!crashes.isEmpty() && now - crashes.peekFirst() > 5 * 60_000) crashes.removeFirst();
            if (crashes.size() > 3) {
                error = "酒馆服务 5 分钟内意外退出了 " + crashes.size() + " 次，已停止自动重启（" + lastExit + "）";
                setPhase("failed", "反复退出");
                return;
            }
        }
        autoRestarts++;
        setPhase("starting", "酒馆服务意外退出（" + lastExit + "），正在自动重启");
        log("服务意外退出（" + lastExit + "），2 秒后自动重启");
        ops.execute(() -> {
            try {
                Thread.sleep(2000);
                if (wantRunning && process == null) startServer();
            } catch (Throwable t) {
                error = String.valueOf(t);
                setPhase("failed", "自动重启失败");
            }
        });
    }

    private void stopLanProxy() {
        lanProxy.stop();
        lanIps = Collections.emptyList();
        lanError = null;
    }

    private void activateLanForProcess(Process p) {
        if (process != p || url == null) return;
        if (!prefs().getBoolean("lanAccess", false)) {
            stopLanProxy();
            notify(status);
            return;
        }
        List<String> candidates = trustedLanIps;
        if (candidates.isEmpty()) {
            if (lanError == null) {
                lanError = "未检测到 Wi-Fi 或局域网地址（请连接 Wi-Fi 或开启热点后点「刷新地址」）";
            }
            notify(status);
            return;
        }
        LanProxy.StartResult res = lanProxy.start(candidates, PORT);
        lanIps = res.boundIps;
        lanError = res.boundIps.isEmpty() ? ("局域网监听失败：" + (res.error != null ? res.error : "未知错误")) : null;
        if (!lanIps.isEmpty()) {
            log("局域网访问已开启：" + String.join("，", lanIps) + "（端口 " + PORT + "）");
        } else {
            log(lanError);
        }
        notify(status);
    }

    private void syncLan() throws Exception {
        boolean enabled = prefs().getBoolean("lanAccess", false);
        if (!enabled) {
            boolean hadProxy = !lanIps.isEmpty() || lanError != null;
            stopLanProxy();
            notify(status);
            if (hadProxy) log("局域网访问已关闭");
            return;
        }
        if (process == null) {
            lanError = null;
            notify(status);
            return;
        }
        List<String> candidates = LanProxy.discoverLanAddresses(this);
        if (candidates.isEmpty()) {
            lanProxy.stop();
            lanIps = Collections.emptyList();
            lanError = "未检测到 Wi-Fi 或局域网地址（请连接 Wi-Fi 或开启热点后点「刷新地址」）";
            notify(status);
            return;
        }
        if (trustedLanIps.containsAll(candidates)) {
            if (url != null) {
                LanProxy.StartResult res = lanProxy.start(candidates, PORT);
                lanIps = res.boundIps;
                lanError = res.boundIps.isEmpty() ? ("局域网监听失败：" + (res.error != null ? res.error : "未知错误")) : null;
                if (!lanIps.isEmpty()) {
                    log("局域网访问已开启：" + String.join("，", lanIps) + "（端口 " + PORT + "）");
                }
                notify(status);
            }
            return;
        }
        log("局域网地址变化，正在重启服务以应用新地址");
        wantRunning = true;
        stopServer();
        startServer();
    }

    private void stopServer() throws InterruptedException {
        stopLanProxy();
        trustedLanIps = Collections.emptyList();
        Process p = process;
        if (p == null) return;
        stopping = true;
        setPhase("stopping", "正在停止");
        p.destroy();
        if (!p.waitFor(8, TimeUnit.SECONDS)) p.destroyForcibly().waitFor(3, TimeUnit.SECONDS);
        process = null;
        url = null;
        applyWakeLock();
    }

    private boolean waitRunning(long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            if (url != null) return true;
            if (process == null) return false;
            Thread.sleep(300);
        }
        return url != null;
    }

    private String describeSource() {
        JSONObject s = readJson(new File(root, "src/.native-source.json"));
        if (s == null) return "";
        String rev = s.optString("revision");
        return "酒馆 v" + s.optString("version") + " · " + (rev.length() > 7 ? rev.substring(0, 7) : rev)
                + ("hot-update".equals(s.optString("from")) ? "（已热更新）" : "");
    }

    // ---------------------------------------------------------------- 更新

    /** 用 libnode.so 跑 source-update.mjs，转发 DSH_STATUS，返回 RESULT。 */
    private JSONObject tool(String... args) throws Exception {
        List<String> command = new ArrayList<>();
        command.add(node().getPath());
        command.add("--use-bundled-ca");
        command.add(root + "/usr/lib/dsh-android/source-update.mjs");
        for (String a : args) command.add(a);
        command.add("--root");
        command.add(root.getPath());
        ProcessBuilder pb = new ProcessBuilder(command);
        baseEnvironment(pb.environment());
        pb.directory(root);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        JSONObject result = null;
        StringBuilder other = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Matcher m = TOOL_STATUS.matcher(line);
                if (m.find()) updateMessage = m.group(1);
                else if (line.startsWith("RESULT ")) result = new JSONObject(line.substring(7));
                else if (other.length() < 4000) other.append(line).append('\n');
            }
        }
        p.waitFor();
        if (result == null) throw new IOException("更新工具没有返回结果：" + other);
        if ("error".equals(result.optString("kind"))) throw new IOException(result.optString("error"));
        return result;
    }

    private void checkUpdates() {
        updateState = "checking";
        updateMessage = "正在检查更新";
        try {
            JSONObject r = tool("check", "--apk-version-code", String.valueOf(versionCode()));
            // 安装包以 Java 读到的发布信息为准（与启动时的自动检查一致）；读不到时才用 Node 读到的旧地址结果。
            JSONObject feed = null;
            try {
                feed = fetchApkFeed();
                prefs().edit().putLong("apkCheckedAt", System.currentTimeMillis()).apply();
            } catch (Exception ignored) {
            }
            JSONObject apk = r.optJSONObject("apk");
            if (feed != null) {
                apkRelease = apkOffered(feed) ? feed : null;
                updateNotice(feed);
            } else {
                apkRelease = apk != null && apk.optBoolean("available") ? apk : null;
            }
            String source = r.optString("source");
            JSONObject latest = r.optJSONObject("latest");
            String latestText = latest == null ? "" : "v" + latest.optString("version") + " · " + latest.optString("revision").substring(0, 7);
            if ("available".equals(source)) {
                updateState = "source";
                String deps = r.optString("deps");
                updateMessage = "true".equals(deps)
                        ? "有新版酒馆 " + latestText + "：依赖有变化，更新时会在手机上补装变化的包（需联网，几分钟，存档和设置保留）"
                        : "maybe".equals(deps)
                        ? "有新版酒馆 " + latestText + "：依赖可能有变化，更新时会在手机上补装变化的包（存档和设置保留）"
                        : "有新版酒馆 " + latestText + "：依赖没变，可以直接更新源码（约 17 MB，存档和设置保留）";
            } else if (apkRelease != null) {
                updateState = "apk";
                updateMessage = apkMessage(apkRelease);
            } else if ("needs-apk".equals(source)) {
                updateState = "needs-apk";
                updateMessage = "有新版酒馆 " + latestText + "，但更换了 DSH 运行时，需要新版安装包；对应的安装包还没发布";
            } else if ("error".equals(source)) {
                updateState = "error";
                updateMessage = "检查失败：" + r.optString("sourceError");
            } else {
                updateState = "up-to-date";
                JSONObject cur = r.optJSONObject("current");
                String warning = r.optString("checkWarning");
                updateMessage = "已是最新" + (cur == null ? "" : "（v" + cur.optString("version") + " · " + cur.optString("revision").substring(0, 7) + "）")
                        + (warning.isEmpty() ? "" : "\n" + warning);
            }
        } catch (Throwable t) {
            updateState = "error";
            updateMessage = "检查失败：" + (t.getMessage() != null ? t.getMessage() : t);
        }
    }

    // ---------------------------------------------------------------- 新版安装包（Java 直接检查，不依赖 Node）

    static String apkMessage(JSONObject r) {
        String notes = r.optString("notes").trim();
        return "有新版安装包 " + r.optString("versionName") + "（" + r.optLong("size") / 1048576 + " MB）"
                + (notes.isEmpty() ? "" : "\n" + notes);
    }

    /** 启动时调用：6 小时内用上次读到的发布信息，否则联网读。失败只记日志，不打扰用户。 */
    private void apkCheck() {
        if (!apkChecking.compareAndSet(false, true)) return;
        try {
            SharedPreferences p = prefs();
            boolean custom = extraEnv().containsKey("DSH_NATIVE_APK_FEED");
            String cached = p.getString("apkLatest", null);
            JSONObject feed;
            if (!custom && cached != null && System.currentTimeMillis() - p.getLong("apkCheckedAt", 0) < APK_CHECK_INTERVAL_MS) {
                feed = new JSONObject(cached);
            } else {
                feed = fetchApkFeed();
                p.edit().putLong("apkCheckedAt", System.currentTimeMillis()).apply();
            }
            updateNotice(feed);
            String us = updateState;
            if (apkRelease != null && ("idle".equals(us) || "up-to-date".equals(us))) {
                updateState = "apk";
                updateMessage = apkMessage(apkRelease);
            }
        } catch (Throwable t) {
            log("检查新版安装包失败：" + (t.getMessage() != null ? t.getMessage() : t));
        } finally {
            apkChecking.set(false);
        }
    }

    /** 按发布信息决定是否提示：版本更新、签名一致；跳过过的版本不再弹，低于 minVersionCode 时不能跳过。 */
    private void updateNotice(JSONObject feed) {
        prefs().edit().putString("apkLatest", feed.toString()).apply();
        long current = 0;
        try {
            current = versionCode();
        } catch (Exception ignored) {
        }
        boolean offered = apkOffered(feed);
        if (offered) apkRelease = feed;
        boolean forced = offered && current < feed.optLong("minVersionCode", 0);
        boolean skipped = prefs().getLong("skipApkVersion", -1) == feed.optLong("versionCode");
        apkForced = forced;
        apkNotice = offered && (forced || !skipped) ? feed : null;
        notify(status);
    }

    private boolean apkOffered(JSONObject feed) {
        try {
            if (feed.optLong("versionCode") <= versionCode()) return false;
            String want = feed.optString("signer").replace(":", "").trim().toLowerCase(Locale.ROOT);
            if (!want.isEmpty() && !want.equals(signerDigest())) {
                log("新版安装包的签名与本机安装的不同（调试版与正式版不能互相覆盖），不提示");
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String signerDigest() throws Exception {
        PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
        android.content.pm.Signature[] signers = info.signingInfo.getApkContentsSigners();
        byte[] digest = java.security.MessageDigest.getInstance("SHA-256").digest(signers[0].toByteArray());
        StringBuilder hex = new StringBuilder();
        for (byte b : digest) hex.append(String.format("%02x", b));
        return hex.toString();
    }

    /** 依次读各发布信息地址，返回第一个有效的；extra-env 的 DSH_NATIVE_APK_FEED 覆盖全部（测试用）。 */
    private JSONObject fetchApkFeed() throws Exception {
        String custom = extraEnv().get("DSH_NATIVE_APK_FEED");
        String[] feeds = custom != null && !custom.isEmpty() ? new String[]{custom} : APK_FEEDS;
        StringBuilder errors = new StringBuilder();
        for (String feed : feeds) {
            try {
                return readApkFeed(feed);
            } catch (Exception e) {
                errors.append("\n").append(feed).append("：").append(e.getMessage());
            }
        }
        throw new IOException("读不到安装包发布信息" + errors);
    }

    private static JSONObject readApkFeed(String feed) throws Exception {
        java.net.URL link = new java.net.URL(feed);
        for (int hop = 0; hop < 5; hop++) {
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) link.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(5_000);
            c.setReadTimeout(8_000);
            c.setUseCaches(false);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("Cache-Control", "no-cache");
            try {
                int code = c.getResponseCode();
                String location = c.getHeaderField("Location");
                if (code >= 300 && code < 400 && location != null) {
                    link = new java.net.URL(link, location);
                    continue;
                }
                if (code != 200) throw new IOException("HTTP " + code);
                ByteArrayOutputStream body = new ByteArrayOutputStream();
                try (InputStream in = c.getInputStream()) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        body.write(buf, 0, n);
                        if (body.size() > 256 * 1024) throw new IOException("发布信息过大");
                    }
                }
                JSONObject info = new JSONObject(new String(body.toByteArray(), StandardCharsets.UTF_8));
                for (String key : new String[]{"versionCode", "versionName", "url", "sha256", "size"}) {
                    if (!info.has(key)) throw new IOException("发布信息缺少 " + key);
                }
                if (info.optLong("versionCode") <= 0 || !info.optString("sha256").matches("(?i)[0-9a-f]{64}")) {
                    throw new IOException("发布信息无效");
                }
                // 相对地址按读到发布信息的最终地址解析（本地测试源用相对地址）。
                info.put("url", new java.net.URL(link, info.getString("url")).toString());
                if (!info.optString("page").isEmpty()) info.put("page", new java.net.URL(link, info.getString("page")).toString());
                info.put("feed", feed);
                return info;
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("重定向次数过多");
    }

    private void sourceUpdate() throws Exception {
        updateState = "updating";
        updateMessage = "正在下载新源码";
        JSONObject staged = tool("stage");
        String kind = staged.optString("kind");
        if ("needs-apk".equals(kind)) {
            updateState = "needs-apk";
            updateMessage = staged.optString("reason");
            return;
        }
        if ("up-to-date".equals(kind)) {
            updateState = "up-to-date";
            updateMessage = "已是最新";
            return;
        }
        boolean deps = staged.optBoolean("deps");
        wantRunning = true;
        updateMessage = "正在停止酒馆";
        stopServer();
        setPhase("updating", "正在更新");
        // 与命令行版更新相同：换源码后跑一遍安装器（补装变化的依赖、刷新内置插件与配置）。
        // 依赖有变化时 node_modules 先整份备份，任何一步失败都能原样换回。
        boolean ok = false;
        String failure = null;
        try {
            updateMessage = "正在切换到新源码";
            if (deps) tool("swap", "--copy-modules");
            else tool("swap");
            updateMessage = "正在备份当前配置";
            if (deps) tool("backup", "--modules");
            else tool("backup");
            updateMessage = deps ? "正在补装变化的依赖" : "正在刷新配置";
            JSONObject installed = tool("install");
            log("安装器完成，用时 " + installed.optLong("ms") / 1000 + " 秒");
            updateMessage = "正在启动新版本";
            startServer();
            ok = waitRunning(180_000);
            if (!ok) failure = "新版本启动失败（" + lastExit + "）";
        } catch (Throwable t) {
            failure = t.getMessage() != null ? t.getMessage() : String.valueOf(t);
        }
        if (ok) {
            tool("commit");
            updateState = "up-to-date";
            updateMessage = "已更新到 " + describeSource() + (deps ? "（依赖已在手机上补装）" : "");
            log(updateMessage);
            return;
        }
        // 新版本装不上或起不来：换回旧的，别让用户卡在打不开的状态。
        log("更新失败，正在回退：" + failure);
        updateMessage = "更新失败，正在回退到原来的版本";
        stopServer();
        setPhase("updating", "正在回退更新");
        tool("rollback");
        startServer();
        updateState = "error";
        updateMessage = "更新失败，已回退到原来的版本：" + failure + "（详情见日志 update.log）";
    }

    /** 流式下载并边下边算 SHA-256：安装包四百多 MB，不能整个读进内存。系统代理由 HttpURLConnection 自动使用。 */
    private void downloadApk() throws Exception {
        JSONObject release = apkRelease;
        if (release == null) throw new IOException("没有可下载的安装包，请先检查更新");
        updateState = "downloading";
        updateMessage = "正在下载安装包";
        File dir = new File(getCacheDir(), "apk");
        deleteTree(dir);
        dir.mkdirs();
        File part = new File(dir, "download.part");
        File target = new File(dir, "dsh-tavern-" + release.optLong("versionCode") + ".apk");
        long size = release.optLong("size");
        java.security.MessageDigest sha = java.security.MessageDigest.getInstance("SHA-256");
        java.net.URL link = new java.net.URL(release.getString("url"));
        for (int hop = 0; hop < 6; hop++) {
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) link.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20_000);
            c.setReadTimeout(60_000);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                link = new java.net.URL(link, c.getHeaderField("Location"));
                c.disconnect();
                continue;
            }
            if (code != 200) throw new IOException("下载安装包失败：HTTP " + code);
            long done = 0, reported = 0;
            try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(part)) {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    sha.update(buf, 0, n);
                    done += n;
                    if (done - reported > (1 << 20)) {
                        reported = done;
                        progress = size > 0 ? (int) Math.min(99, done * 100 / size) : -1;
                        updateMessage = "正在下载安装包 " + done / 1048576 + " / " + size / 1048576 + " MB";
                    }
                }
            } finally {
                c.disconnect();
            }
            progress = -1;
            StringBuilder hex = new StringBuilder();
            for (byte b : sha.digest()) hex.append(String.format("%02x", b));
            if (!hex.toString().equalsIgnoreCase(release.getString("sha256"))) {
                part.delete();
                throw new IOException("安装包校验失败（SHA-256 不符），已删除，请重试");
            }
            if (!part.renameTo(target)) throw new IOException("无法保存安装包");
            apkFile = target.getPath();
            updateState = "ready";
            updateMessage = "安装包已下载并校验，点「安装」覆盖安装（存档和设置保留）";
            return;
        }
        throw new IOException("下载安装包失败：重定向次数过多");
    }
}
