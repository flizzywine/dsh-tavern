import { type JSX } from 'react';
import type { SkillsLocation, SkillsPageContext } from './ui.tsx';
export declare function MarketPage(props: {
    context: SkillsPageContext;
    location: SkillsLocation;
}): JSX.Element;
